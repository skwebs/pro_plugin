<?php
/**
 * Index file
 *
 * @package Astra
 * @since Astra 1.2.0
 */

/* Silence is golden, and we agree. */
